// script.js
const clickArea = document.getElementById('click-area');
const balanceDisplay = document.getElementById('coin-balance'); // Исправлено: id вместо класса
const clickableImage = document.getElementById('clickable-image');

let balance = 0;

function getBalance() {
  return parseInt(localStorage.getItem('coinBalance') || '0', 10);
}

function saveBalance(newBalance) {
  localStorage.setItem('coinBalance', newBalance);
}

function updateBalanceDisplay() {
  balanceDisplay.textContent = getBalance();
}

balance = getBalance();
updateBalanceDisplay();

function getRandomCoins() {
  return Math.floor(Math.random() * 5) + 1;
}

clickArea.addEventListener('click', () => {
  const earnedCoins = getRandomCoins();
  balance += earnedCoins;
  saveBalance(balance);
  updateBalanceDisplay();
  clickableImage.click();
  // ... (остальной код для анимации монет)
});

// Обработчик сообщений из task.html
// ... (ваш код без изменений) ...

// Обработчик сообщений из task.html
window.addEventListener('message', (event) => {
    if (event.data.type === 'taskCompleted') {
      balance = getBalance(); // Обновляем баланс из localStorage
      updateBalanceDisplay(); 
    }
  });
  
  // ... (ваш код без изменений) ... 
  