const taskList = document.querySelectorAll('.task-list a');

function isTaskCompleted(taskId) {
  const completedTasks = JSON.parse(localStorage.getItem('completedTasks') || '{}');
  return completedTasks[taskId];
}

function markTaskCompleted(taskId) {
  const completedTasks = JSON.parse(localStorage.getItem('completedTasks') || '{}');
  completedTasks[taskId] = true;
  localStorage.setItem('completedTasks', JSON.stringify(completedTasks));
}

function updateTaskItem(taskItem) {
  const taskId = taskItem.dataset.taskId;

  if (isTaskCompleted(taskId)) {
    taskItem.classList.add('completed');
    const link = taskItem.querySelector('a');
    link.removeAttribute('href'); 
  } else {
    taskItem.classList.remove('completed');
    const link = taskItem.querySelector('a');
    link.href = link.dataset.originalHref; 
  }
}

function showCustomAlert(message) {
  if (message) { 
    document.getElementById('alertMessage').innerText = message;
    document.getElementById('customAlert').style.display = 'block';
  }
}

window.addEventListener('load', () => {
  const taskItems = document.querySelectorAll('.task-item');
  taskItems.forEach(updateTaskItem);

  const completedTaskId = localStorage.getItem('pendingTaskId');

  // Проверяем, не было ли это задание уже выполнено
  if (completedTaskId && !isTaskCompleted(completedTaskId) && !localStorage.getItem('taskCompleted-' + completedTaskId)) { 
    markTaskCompleted(completedTaskId);

    let currentBalance = parseInt(localStorage.getItem('coinBalance') || '0', 10);
    const earnedCoins = 10000;
    localStorage.setItem('coinBalance', currentBalance + earnedCoins);

    // Отправляем сообщение на index.html
    window.parent.postMessage({ type: 'taskCompleted', taskId: completedTaskId }, '*');

    const completedTaskItem = document.querySelector(`.task-item[data-task-id="${completedTaskId}"]`);
    if (completedTaskItem) {
      updateTaskItem(completedTaskItem);
    }

    const message = 'Поздравляем! Вам начислено 10000 монет!';
    showCustomAlert(message); 

    // Помечаем задание как обработанное 
    localStorage.setItem('taskCompleted-' + completedTaskId, 'true');
  } 

  localStorage.removeItem('pendingTaskId'); 
  localStorage.removeItem('taskCompleted-' + completedTaskId); // Удаляем метку
});

taskList.forEach(link => {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    const taskItem = link.closest('.task-item');
    const taskId = taskItem.dataset.taskId;

    if (!isTaskCompleted(taskId)) {
      localStorage.setItem('pendingTaskId', taskId);

      // Удаляем метку перед переходом по ссылке
      localStorage.removeItem('taskCompleted-' + taskId);

      window.location.href = link.href; 
    } else {
      showCustomAlert('Это задание уже выполнено!'); 
    }
  });
});

document.getElementById('alertClose').addEventListener('click', () => {
  document.getElementById('customAlert').style.display = 'none';
});

document.getElementById('customAlert').addEventListener('click', (event) => {
  if (event.target === document.getElementById('customAlert')) { 
    document.getElementById('customAlert').style.display = 'none';
  }
});
